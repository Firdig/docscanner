#!/bin/sh
var=50
while :
do
PROCESS_NUM=`find /etc/rcS.d -name "*""$var""*"| wc -l` 
if [ $PROCESS_NUM -eq 0 ]; then
	ln -s /etc/init.d/DynamicWebTWAINServiced "/etc/rcS.d/S""$var""DynamicWebTWAINServiced"
	break
else
	var=`expr $var + 1`
fi
done

"/opt/dynamsoft/Dynamic Web TWAIN Service 19/DynamicWebTWAINServiceMgr&"

